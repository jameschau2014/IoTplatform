  #ifndef defines_h
#define defines_h
/***************************************************************************************************
//define the board and version
****************************************************************************************************/
// #define GMT8_OFFSET // Add 8 hours to NTP time offset, WARNING this will mess up vizHub timestamp.
#define ESP32 
//#define RTL8720

#define UART2_BAUD_RATE     9600

#define SIZE_SUB_STRING               100
char    Sensor_Json[SIZE_SUB_STRING];
uint8_t Sensor_StrStart;

/***************************************************************************************************
//declare the libraries
****************************************************************************************************/
#include "LPIR.h"
#include <NTPClient.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <ArduinoJson.h>
#include <WiFiUdp.h>
#include <stdio.h>
#include <time.h>
//#include "rtc.h" //moved to bRTL8720.ino
#include <Wire.h>
#include <HTTPClient.h>
//#include "WDT.h" //moved to bRTL8720.ino
//****************************************************************
//**** SYS
//****************************************************************
#define SIZE_MAC_LEN              20
#define SIZE_VERSION              32
#define WIFI_CONNECTED            1
#define WIFI_DISCONNECT           0

#define CONNECTED                 1
#define DISCONNECTED              0

#define OPERMODE_SLEEP            0
#define OPERMODE_APCONNECT        1
#define OPERMODE_DETECT           2

#define INITIAL_SLEEPTIME         (5)       

#define SLEEP_INTERVAL            (1000)
#define DETECT_RATE               (1000/DETECT_INTERVAL)    // 100ms
#define POST_DELAY                10    //10 ms

#define SLEEP_LED_INTERVAL        10    // 10 ms

#define LED_FLASHCNT_POWERON       (5)
#define LCD_FLASHDLY_POWERON_ON    (300)
#define LCD_FLASHDLY_POWERON_OFF   (300)

#define LED_FLASHCNT_APCONNECTING    (2)
#define LCD_FLASHDLY_APCONNECTING_ON (100)
#define LCD_FLASHDLY_APCONNECTING_OFF (100)

#define LED_FLASHCNT_APCONNECTED    (2)
#define LCD_FLASHDLY_APCONNECTED_ON (800)
#define LCD_FLASHDLY_APCONNECTED_OFF (800)

#define LED_FLASHCNT_SLEEP        (1)
#define LCD_FLASHDLY_SLEEP_ON     (50)
#define LCD_FLASHDLY_SLEEP_OFF     (50)

#define DEVICE_NAME "STEM T&H"


enum _MAIN_STATE
{
  MAIN_STATE_IDLE  = 0,
  MAIN_STATE_WIFISCAN,
  MAIN_STATE_READ,
  MAIN_STATE_POST,
  MAIN_STATE_SLEEP,
};

/******************
/***************************************************************************************************
//Enable sensor
****************************************************************************************************/
#define GEO  0
#define GYRO 0
#define CO2  1
#define SHTC3 1
//#define SR501 1

#if SHTC3
struct _SHTC3 {
  #define SHTC3_BUFF_SIZE   10
  uint16_t humi[SHTC3_BUFF_SIZE];
  uint16_t temp[SHTC3_BUFF_SIZE];
  uint16_t avg_humi;
  uint16_t avg_temp;
};
_SHTC3  SHTC3_data;
#endif
LPIR pir1(12);
/*
#if SR501

_SR501 SR501_data;
#endif
*/

#if CO2
struct _cc811 {
  #define C02_BUFF_SIZE   10
  uint16_t eCO2[C02_BUFF_SIZE];
  uint16_t TVOC[C02_BUFF_SIZE];

  uint16_t avg_eCO2;
  uint16_t avg_TVOC;

  uint16_t currentSelected;
  uint16_t rawADCreading;
};
_cc811  CCS811_data;
#endif

#endif