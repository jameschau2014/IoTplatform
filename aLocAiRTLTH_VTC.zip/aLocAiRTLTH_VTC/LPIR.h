// LPIR.h

#ifndef LPIR_h
#define LPIR_h

#include "Arduino.h"
#define PIR_OFF 0
#define PIR_ON 1
#define LPIR_BUFF_SIZE 10
class LPIR
{
public:
  LPIR(int pin);
  uint8_t getValue();
  uint8_t getUploadValue();
  void app_pir_init(); // reserved, currently not used
  // void setLastTime(int32_t t);
  // char[8] getLastTime();
private:

  //int32_t _timebuffer;
  uint8_t _sta;
  uint8_t _pin;
};

#endif