//LPIR.cpp

#include "Arduino.h"
#include "LPIR.h"

LPIR::LPIR(int pin)
{
  pinMode(pin, INPUT);
  _pin = pin;
}

void LPIR::app_pir_init(void)
{
  pinMode(_pin, INPUT);
}

uint8_t LPIR::getValue()
{
  if (digitalRead(_pin) == PIR_ON)
  {
    _sta = PIR_ON;
  }
  else if (digitalRead(_pin) == PIR_OFF)
  {
    _sta = PIR_OFF;
  }
  return _sta;
}

uint8_t LPIR::getUploadValue()
{
  bool pir_temp_sta = 0;
  for (uint8_t p = 0; p < 10; p++)
  {
    if (getValue() == PIR_ON && pir_temp_sta == PIR_OFF)
    {
      pir_temp_sta = PIR_ON;
    }
    delay(70); //Need to change afterwards
  }
  if (pir_temp_sta)
  {
    _sta = PIR_ON;
  }
  else
  {
    _sta = PIR_OFF;
  }
  return _sta;
}


// void LPIR::setLastTime(int32_t t)
// {
//   _timebuffer = t;
// }

// char[8] LPIR::getLastTime()
// {
//   return _timebuffer;
// }