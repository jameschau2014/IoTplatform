#ifndef _DISPDRV_SSD1306_H
#define _DISPDRV_SSD1306_H

#define DISPDRV_FONT_8 8
#define DISPDRV_FONT_16 16

#define LCD_DRIVER_SPI
//#define LCD_SIZE_09


#endif

#define dispDrv_CMD 0  // commmand
#define dispDrv_DATA 1 // Data